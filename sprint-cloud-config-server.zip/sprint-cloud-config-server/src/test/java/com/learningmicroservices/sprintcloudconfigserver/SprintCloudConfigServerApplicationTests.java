package com.learningmicroservices.sprintcloudconfigserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SprintCloudConfigServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
