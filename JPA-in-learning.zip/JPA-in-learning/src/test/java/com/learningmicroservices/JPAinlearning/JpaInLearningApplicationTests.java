package com.learningmicroservices.JPAinlearning;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JpaInLearningApplicationTests {

	@Test
	void contextLoads() {
	}

}
