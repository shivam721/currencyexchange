package com.learnwebservices.restfulwebservices;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestFulWebservicesApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestFulWebservicesApplication.class, args);
	}

}
